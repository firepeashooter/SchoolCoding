#ifndef A5_H
#define A5_H

#include <stdio.h>

int strind(const char *s, char c);


char strmaxfreq(const char *s);

char *strrepeat(const char *s, size_t n);

void strselfcat(char **s);

void strrmlast(char *s, char c);



#endif
